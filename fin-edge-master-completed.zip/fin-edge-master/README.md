# FinEdge API

A RESTful backend for personal finance and expense tracking built with Node.js and Express.

## Features

- User Registration
- JWT Authentication
- Transaction Management
- Budget Tracking
- Financial Summary
- Monthly Analytics
- Request Validation
- Rate Limiting
- Error Handling
- Unit Tests
- Modular MVC Architecture
- JSON file persistence with `fs/promises`

## Tech Stack

- Node.js
- Express.js
- JSON file storage for current user module
- JWT
- Express Validator
- Jest
- Supertest

## Project Structure

```
src/
controllers/
routes/
services/
models/
middleware/
utils/
validations/
cache/
config/
tests/
```

## Installation

```bash
git clone <repo>

cd finedge-api

npm install
```

Create a `.env` file.

```env
PORT=5000
NODE_ENV=development
MONGO_URI=mongodb://127.0.0.1:27017/finedge
JWT_SECRET=replace-with-a-long-secret
JWT_EXPIRES_IN=7d
```

Run

```bash
npm run dev
```

## API Base URL

```
http://localhost:5000/api/v1
```

## Implemented Module: User Authentication & Preferences

The user module has been implemented with MVC structure, async file persistence, input validation, password hashing, JWT session handling, and tests.

Implemented features:

- User registration
- User login
- JWT-based protected routes
- Password hashing with `bcryptjs`
- Get logged-in user profile
- Update profile details
- Delete user account
- Get and update user finance preferences
- Change password
- Duplicate email handling
- Validation for auth, profile, preferences, and password inputs
- User data stored in `src/data/users.json` using `fs/promises`

## User API Endpoints

| Method | Endpoint | Auth Required | Description |
| --- | --- | --- | --- |
| `POST` | `/api/v1/users` | No | Register a new user |
| `POST` | `/api/v1/users/login` | No | Login and receive a JWT token |
| `GET` | `/api/v1/users/me` | Yes | Fetch logged-in user profile |
| `PATCH` | `/api/v1/users/me` | Yes | Update logged-in user profile |
| `DELETE` | `/api/v1/users/me` | Yes | Delete logged-in user account |
| `GET` | `/api/v1/users/preferences` | Yes | Fetch user preferences |
| `PATCH` | `/api/v1/users/preferences` | Yes | Update finance preferences |
| `PATCH` | `/api/v1/users/password` | Yes | Change account password |

Protected routes require this header:

```http
Authorization: Bearer <token>
```

## Example Requests

### Register

```http
POST /api/v1/users
```

```json
{
  "name": "Dev Parmar",
  "email": "dev@example.com",
  "password": "devdevdev",
  "preferences": {
    "currency": "INR",
    "monthlySavingsGoal": 5000
  }
}
```

### Login

```http
POST /api/v1/users/login
```

```json
{
  "email": "dev@example.com",
  "password": "devdevdev"
}
```

### Update Preferences

```http
PATCH /api/v1/users/preferences
```

```json
{
  "preferences": {
    "currency": "USD",
    "monthlySavingsGoal": 7500,
    "categories": ["food", "rent", "travel"]
  }
}
```

### Change Password

```http
PATCH /api/v1/users/password
```

```json
{
  "currentPassword": "devdevdev",
  "newPassword": "newdevdev"
}
```

## Implemented Module: Transactions & Budget

The transactions and budget module has been implemented with MVC structure, async file
persistence, input validation, and ownership scoped to the logged-in user (via the JWT
from the user module). A `/summary` endpoint aggregates income/expense data and is backed
by an in-memory TTL cache.

Implemented features:

- Add, view, update, and delete transactions (`type`, `category`, `amount`, `date`, optional `description`)
- Filter transactions by `type`, `category`, `startDate`, `endDate`
- Create, view, update, and delete monthly budgets (`month`, `monthlyGoal`, `savingsTarget`, optional `categoryLimits`)
- One budget per user per month (duplicate months are rejected with `409 BUDGET_EXISTS`)
- Transaction and budget data stored in `src/data/transactions.json` and `src/data/budgets.json` using `fs/promises`
- Custom validation middleware built with `express-validator`
- `/api/v1/summary` returns total income, total expense, balance, monthly trends, and a category breakdown
- Summary results are cached in-memory (`src/cache/memoryCache.js`) for 30 seconds per user/filter combination and invalidated automatically whenever that user's transactions change
- All routes are protected with the existing JWT `authMiddleware`

## Transaction & Budget API Endpoints

| Method | Endpoint | Auth Required | Description |
| --- | --- | --- | --- |
| `POST` | `/api/v1/transactions` | Yes | Add a new income/expense transaction |
| `GET` | `/api/v1/transactions` | Yes | List transactions (supports `?type=`, `?category=`, `?startDate=`, `?endDate=`) |
| `GET` | `/api/v1/transactions/:id` | Yes | View a single transaction |
| `PATCH` | `/api/v1/transactions/:id` | Yes | Update a transaction |
| `DELETE` | `/api/v1/transactions/:id` | Yes | Delete a transaction |
| `POST` | `/api/v1/budgets` | Yes | Create a monthly budget |
| `GET` | `/api/v1/budgets` | Yes | List all budgets |
| `GET` | `/api/v1/budgets/:id` | Yes | View a single budget |
| `PATCH` | `/api/v1/budgets/:id` | Yes | Update a budget |
| `DELETE` | `/api/v1/budgets/:id` | Yes | Delete a budget |
| `GET` | `/api/v1/summary` | Yes | Income/expense summary, monthly trends, category breakdown |

### Add Transaction

```http
POST /api/v1/transactions
```

```json
{
  "type": "income",
  "category": "Salary",
  "amount": 50000,
  "date": "2026-07-01",
  "description": "July salary"
}
```

### Create Budget

```http
POST /api/v1/budgets
```

```json
{
  "month": "2026-07",
  "monthlyGoal": 40000,
  "savingsTarget": 8000,
  "categoryLimits": { "food": 5000 }
}
```

### Summary

```http
GET /api/v1/summary?category=Food&startDate=2026-07-01&endDate=2026-07-31
```

Returns `totalIncome`, `totalExpense`, `balance`, `transactionCount`, `monthlyTrends`, `categoryBreakdown`, and a `cached` flag indicating whether the response was served from cache.

## Tests

Run:

```bash
npm test
```

Current test coverage:

- User module: register, reject duplicate email, login, fetch protected profile, update profile, get/update preferences, change password, delete account, validate invalid input
- Transaction module: create, validation errors, auth requirement, list, filter by type, fetch by id, 404 on missing id, update, delete
- Budget module: create, reject duplicate month, validation errors, list, update, delete
- Summary module: totals/balance/trends computation, cache hit on repeat calls, cache invalidation after a new transaction, auth requirement
