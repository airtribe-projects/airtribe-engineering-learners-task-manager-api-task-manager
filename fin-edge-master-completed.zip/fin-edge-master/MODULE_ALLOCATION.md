# FinEdge Module Allocation

## Member 1: User Authentication & Preferences

Status: Implemented on `feature_pdev`.

Deliverables:

- `POST /api/v1/users` for user registration
- `POST /api/v1/users/login` for login
- `GET /api/v1/users/me` for protected profile lookup
- `PATCH /api/v1/users/me` for profile updates
- `DELETE /api/v1/users/me` for account deletion
- `GET /api/v1/users/preferences` for user finance preferences
- `PATCH /api/v1/users/preferences` for updating currency, savings goal, and categories
- `PATCH /api/v1/users/password` for password changes
- JWT-based user session
- Password hashing with `bcryptjs`
- User, profile, preference, and password validation with `express-validator`
- JSON file persistence using `fs/promises`
- Tests for register, duplicate email, login, validation, protected route, profile update, preferences, password change, and account deletion

Files:

- `src/routes/user.routes.js`
- `src/controllers/user.controller.js`
- `src/services/user.service.js`
- `src/models/user.model.js`
- `src/middleware/auth.middleware.js`
- `src/validations/user.validation.js`
- `src/data/users.json`
- `src/tests/user.test.js`

## Member 2: Transactions & Budget

Suggested deliverables:

- `POST /api/v1/transactions`
- `GET /api/v1/transactions`
- `GET /api/v1/transactions/:id`
- `PATCH /api/v1/transactions/:id`
- `DELETE /api/v1/transactions/:id`
- Transaction fields: `type`, `category`, `amount`, `date`, optional `description`
- Transaction input validation middleware
- JSON persistence in `src/data/transactions.json`
- `POST /api/v1/budgets`
- `GET /api/v1/budgets`
- `GET /api/v1/budgets/:id`
- `PATCH /api/v1/budgets/:id`
- `DELETE /api/v1/budgets/:id`
- Budget fields: `month`, `monthlyGoal`, `savingsTarget`, category limits
- Tests for transaction CRUD and budget CRUD

Recommended files:

- `src/routes/transaction.routes.js`
- `src/controllers/transaction.controller.js`
- `src/services/transaction.service.js`
- `src/models/transaction.model.js`
- `src/validations/transaction.validation.js`
- `src/routes/budget.routes.js`
- `src/controllers/budget.controller.js`
- `src/services/budget.service.js`
- `src/models/budget.model.js`
- `src/validations/budget.validation.js`

## Member 3: Common Setup, Analytics, Bonus, Docs

Suggested deliverables:

- Mount transaction, budget, and summary routes in `src/routes/index.js`
- Improve global error handling and response format if needed
- Keep request logging middleware consistent and optionally disable logs during tests
- Add `/api/v1/summary`
- Calculate total income, expenses, and balance
- Add filters by category and date
- Add monthly trends
- Use `src/cache/memoryCache.js` with TTL for `/summary`
- Add rate limiter middleware
- Update README with setup and API examples
- Add Postman collection
- Add tests for `/health`, `/summary`, cache behavior, rate limits, and common errors

Recommended files:

- `src/routes/summary.routes.js`
- `src/controllers/summary.controller.js`
- `src/services/summary.service.js`
- `src/cache/memoryCache.js`
- `src/middleware/error.middleware.js`
- `src/middleware/logger.middleware.js`
- `src/middleware/rateLimiter.middleware.js`
- `README.md`
