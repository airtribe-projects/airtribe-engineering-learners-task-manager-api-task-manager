const fs = require("fs/promises");
const path = require("path");

const transactionsFilePath = path.join(__dirname, "..", "data", "transactions.json");

const ensureTransactionsFile = async () => {
  await fs.mkdir(path.dirname(transactionsFilePath), { recursive: true });

  try {
    await fs.access(transactionsFilePath);
  } catch (error) {
    await fs.writeFile(transactionsFilePath, "[]");
  }
};

const readTransactions = async () => {
  await ensureTransactionsFile();
  const data = await fs.readFile(transactionsFilePath, "utf8");
  return JSON.parse(data || "[]");
};

const writeTransactions = async (transactions) => {
  await ensureTransactionsFile();
  await fs.writeFile(transactionsFilePath, JSON.stringify(transactions, null, 2));
};

const createTransaction = async (transaction) => {
  const transactions = await readTransactions();
  transactions.push(transaction);
  await writeTransactions(transactions);
  return transaction;
};

const findTransactionsByUserId = async (userId) => {
  const transactions = await readTransactions();
  return transactions.filter((transaction) => transaction.userId === userId);
};

const findTransactionById = async (id, userId) => {
  const transactions = await readTransactions();
  return (
    transactions.find(
      (transaction) => transaction.id === id && transaction.userId === userId
    ) || null
  );
};

const updateTransactionById = async (id, userId, updates) => {
  const transactions = await readTransactions();
  const index = transactions.findIndex(
    (transaction) => transaction.id === id && transaction.userId === userId
  );

  if (index === -1) {
    return null;
  }

  transactions[index] = {
    ...transactions[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };

  await writeTransactions(transactions);
  return transactions[index];
};

const deleteTransactionById = async (id, userId) => {
  const transactions = await readTransactions();
  const filtered = transactions.filter(
    (transaction) => !(transaction.id === id && transaction.userId === userId)
  );

  if (filtered.length === transactions.length) {
    return false;
  }

  await writeTransactions(filtered);
  return true;
};

const replaceTransactions = async (transactions) => {
  await writeTransactions(transactions);
};

module.exports = {
  createTransaction,
  findTransactionsByUserId,
  findTransactionById,
  updateTransactionById,
  deleteTransactionById,
  readTransactions,
  replaceTransactions,
};
