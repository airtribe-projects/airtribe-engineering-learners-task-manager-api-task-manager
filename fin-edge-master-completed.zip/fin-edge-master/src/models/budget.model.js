const fs = require("fs/promises");
const path = require("path");

const budgetsFilePath = path.join(__dirname, "..", "data", "budgets.json");

const ensureBudgetsFile = async () => {
  await fs.mkdir(path.dirname(budgetsFilePath), { recursive: true });

  try {
    await fs.access(budgetsFilePath);
  } catch (error) {
    await fs.writeFile(budgetsFilePath, "[]");
  }
};

const readBudgets = async () => {
  await ensureBudgetsFile();
  const data = await fs.readFile(budgetsFilePath, "utf8");
  return JSON.parse(data || "[]");
};

const writeBudgets = async (budgets) => {
  await ensureBudgetsFile();
  await fs.writeFile(budgetsFilePath, JSON.stringify(budgets, null, 2));
};

const createBudget = async (budget) => {
  const budgets = await readBudgets();
  budgets.push(budget);
  await writeBudgets(budgets);
  return budget;
};

const findBudgetsByUserId = async (userId) => {
  const budgets = await readBudgets();
  return budgets.filter((budget) => budget.userId === userId);
};

const findBudgetById = async (id, userId) => {
  const budgets = await readBudgets();
  return budgets.find((budget) => budget.id === id && budget.userId === userId) || null;
};

const findBudgetByMonth = async (userId, month) => {
  const budgets = await readBudgets();
  return budgets.find((budget) => budget.userId === userId && budget.month === month) || null;
};

const updateBudgetById = async (id, userId, updates) => {
  const budgets = await readBudgets();
  const index = budgets.findIndex((budget) => budget.id === id && budget.userId === userId);

  if (index === -1) {
    return null;
  }

  budgets[index] = {
    ...budgets[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };

  await writeBudgets(budgets);
  return budgets[index];
};

const deleteBudgetById = async (id, userId) => {
  const budgets = await readBudgets();
  const filtered = budgets.filter((budget) => !(budget.id === id && budget.userId === userId));

  if (filtered.length === budgets.length) {
    return false;
  }

  await writeBudgets(filtered);
  return true;
};

const replaceBudgets = async (budgets) => {
  await writeBudgets(budgets);
};

module.exports = {
  createBudget,
  findBudgetsByUserId,
  findBudgetById,
  findBudgetByMonth,
  updateBudgetById,
  deleteBudgetById,
  readBudgets,
  replaceBudgets,
};
