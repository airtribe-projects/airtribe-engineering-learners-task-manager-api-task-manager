const fs = require("fs/promises");
const path = require("path");

const usersFilePath = path.join(__dirname, "..", "data", "users.json");

const ensureUsersFile = async () => {
  await fs.mkdir(path.dirname(usersFilePath), { recursive: true });

  try {
    await fs.access(usersFilePath);
  } catch (error) {
    await fs.writeFile(usersFilePath, "[]");
  }
};

const readUsers = async () => {
  await ensureUsersFile();
  const data = await fs.readFile(usersFilePath, "utf8");
  return JSON.parse(data || "[]");
};

const writeUsers = async (users) => {
  await ensureUsersFile();
  await fs.writeFile(usersFilePath, JSON.stringify(users, null, 2));
};

const createUser = async (user) => {
  const users = await readUsers();
  users.push(user);
  await writeUsers(users);
  return user;
};

const findUserByEmail = async (email) => {
  const users = await readUsers();
  return users.find((user) => user.email === email) || null;
};

const findUserById = async (id) => {
  const users = await readUsers();
  return users.find((user) => user.id === id) || null;
};

const updateUserById = async (id, updates) => {
  const users = await readUsers();
  const userIndex = users.findIndex((user) => user.id === id);

  if (userIndex === -1) {
    return null;
  }

  users[userIndex] = {
    ...users[userIndex],
    ...updates,
    updatedAt: new Date().toISOString(),
  };

  await writeUsers(users);
  return users[userIndex];
};

const deleteUserById = async (id) => {
  const users = await readUsers();
  const filteredUsers = users.filter((user) => user.id !== id);

  if (filteredUsers.length === users.length) {
    return false;
  }

  await writeUsers(filteredUsers);
  return true;
};

const replaceUsers = async (users) => {
  await writeUsers(users);
};

module.exports = {
  createUser,
  findUserByEmail,
  findUserById,
  updateUserById,
  deleteUserById,
  readUsers,
  replaceUsers,
};
