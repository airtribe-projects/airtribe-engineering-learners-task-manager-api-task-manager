// Simple in-memory cache with TTL (time-to-live) expiry.
// Used by the summary service to avoid recomputing income/expense
// aggregates on every request.

const store = new Map();

/**
 * Get a cached value by key. Returns undefined if the key does not
 * exist or has expired (and cleans up the expired entry).
 */
const get = (key) => {
  const entry = store.get(key);

  if (!entry) {
    return undefined;
  }

  if (Date.now() > entry.expiresAt) {
    store.delete(key);
    return undefined;
  }

  return entry.value;
};

/**
 * Store a value under `key` for `ttlMs` milliseconds.
 */
const set = (key, value, ttlMs) => {
  store.set(key, {
    value,
    expiresAt: Date.now() + ttlMs,
  });
};

/**
 * Delete a single cache entry.
 */
const del = (key) => {
  store.delete(key);
};

/**
 * Delete every cache entry whose key starts with `prefix`.
 * Useful for invalidating all cached summaries for a given user
 * whenever their transactions or budgets change.
 */
const clearByPrefix = (prefix) => {
  for (const key of store.keys()) {
    if (key.startsWith(prefix)) {
      store.delete(key);
    }
  }
};

/**
 * Clear the entire cache. Mainly useful for tests.
 */
const clearAll = () => {
  store.clear();
};

module.exports = {
  get,
  set,
  del,
  clearByPrefix,
  clearAll,
};
