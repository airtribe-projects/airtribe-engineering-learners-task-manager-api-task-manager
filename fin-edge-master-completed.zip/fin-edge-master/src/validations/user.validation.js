const { body, validationResult } = require("express-validator");

const ApiError = require("../utils/ApiError");

const handleValidation = (req, res, next) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    const message = errors
      .array()
      .map((error) => error.msg)
      .join(", ");

    return next(new ApiError(400, message, "VALIDATION_ERROR"));
  }

  return next();
};

const registerValidation = [
  body("name")
    .trim()
    .notEmpty()
    .withMessage("Name is required")
    .isLength({ min: 2 })
    .withMessage("Name must be at least 2 characters long"),
  body("email")
    .trim()
    .notEmpty()
    .withMessage("Email is required")
    .isEmail()
    .withMessage("Email must be valid")
    .normalizeEmail(),
  body("password")
    .notEmpty()
    .withMessage("Password is required")
    .isLength({ min: 6 })
    .withMessage("Password must be at least 6 characters long"),
  body("preferences").optional().isObject().withMessage("Preferences must be an object"),
  handleValidation,
];

const loginValidation = [
  body("email")
    .trim()
    .notEmpty()
    .withMessage("Email is required")
    .isEmail()
    .withMessage("Email must be valid")
    .normalizeEmail(),
  body("password").notEmpty().withMessage("Password is required"),
  handleValidation,
];

const updateProfileValidation = [
  body("name")
    .optional()
    .trim()
    .isLength({ min: 2 })
    .withMessage("Name must be at least 2 characters long"),
  body("email")
    .optional()
    .trim()
    .isEmail()
    .withMessage("Email must be valid")
    .normalizeEmail(),
  handleValidation,
];

const preferencesValidation = [
  body("preferences").isObject().withMessage("Preferences must be an object"),
  body("preferences.currency")
    .optional()
    .isString()
    .withMessage("Currency must be a string")
    .trim()
    .isLength({ min: 3, max: 3 })
    .withMessage("Currency must be a 3-letter code"),
  body("preferences.monthlySavingsGoal")
    .optional()
    .isFloat({ min: 0 })
    .withMessage("Monthly savings goal must be a positive number"),
  body("preferences.categories")
    .optional()
    .isArray()
    .withMessage("Categories must be an array"),
  body("preferences.categories.*")
    .optional()
    .isString()
    .withMessage("Each category must be a string")
    .trim()
    .notEmpty()
    .withMessage("Categories cannot contain empty values"),
  handleValidation,
];

const changePasswordValidation = [
  body("currentPassword").notEmpty().withMessage("Current password is required"),
  body("newPassword")
    .notEmpty()
    .withMessage("New password is required")
    .isLength({ min: 6 })
    .withMessage("New password must be at least 6 characters long"),
  handleValidation,
];

module.exports = {
  changePasswordValidation,
  loginValidation,
  preferencesValidation,
  registerValidation,
  updateProfileValidation,
};
