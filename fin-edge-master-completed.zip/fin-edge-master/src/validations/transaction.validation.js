const { body, param, query, validationResult } = require("express-validator");

const ApiError = require("../utils/ApiError");
const { TRANSACTION_TYPES } = require("../utils/constants");

const handleValidation = (req, res, next) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    const message = errors
      .array()
      .map((error) => error.msg)
      .join(", ");

    return next(new ApiError(400, message, "VALIDATION_ERROR"));
  }

  return next();
};

const createTransactionValidation = [
  body("type")
    .trim()
    .notEmpty()
    .withMessage("Type is required")
    .isIn(TRANSACTION_TYPES)
    .withMessage(`Type must be one of: ${TRANSACTION_TYPES.join(", ")}`),
  body("category")
    .trim()
    .notEmpty()
    .withMessage("Category is required")
    .isLength({ min: 2, max: 50 })
    .withMessage("Category must be between 2 and 50 characters"),
  body("amount")
    .notEmpty()
    .withMessage("Amount is required")
    .isFloat({ gt: 0 })
    .withMessage("Amount must be a positive number"),
  body("date")
    .notEmpty()
    .withMessage("Date is required")
    .isISO8601()
    .withMessage("Date must be a valid ISO 8601 date"),
  body("description")
    .optional()
    .trim()
    .isLength({ max: 200 })
    .withMessage("Description must be at most 200 characters"),
  handleValidation,
];

const updateTransactionValidation = [
  body("type")
    .optional()
    .trim()
    .isIn(TRANSACTION_TYPES)
    .withMessage(`Type must be one of: ${TRANSACTION_TYPES.join(", ")}`),
  body("category")
    .optional()
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage("Category must be between 2 and 50 characters"),
  body("amount")
    .optional()
    .isFloat({ gt: 0 })
    .withMessage("Amount must be a positive number"),
  body("date").optional().isISO8601().withMessage("Date must be a valid ISO 8601 date"),
  body("description")
    .optional()
    .trim()
    .isLength({ max: 200 })
    .withMessage("Description must be at most 200 characters"),
  handleValidation,
];

const transactionIdValidation = [
  param("id").trim().notEmpty().withMessage("Transaction id is required"),
  handleValidation,
];

const listTransactionsValidation = [
  query("type")
    .optional()
    .trim()
    .isIn(TRANSACTION_TYPES)
    .withMessage(`Type must be one of: ${TRANSACTION_TYPES.join(", ")}`),
  query("category").optional().trim().isLength({ min: 1 }),
  query("startDate").optional().isISO8601().withMessage("startDate must be a valid ISO 8601 date"),
  query("endDate").optional().isISO8601().withMessage("endDate must be a valid ISO 8601 date"),
  handleValidation,
];

module.exports = {
  createTransactionValidation,
  updateTransactionValidation,
  transactionIdValidation,
  listTransactionsValidation,
};
