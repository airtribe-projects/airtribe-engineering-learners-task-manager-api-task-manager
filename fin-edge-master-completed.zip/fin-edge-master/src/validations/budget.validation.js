const { body, param, validationResult } = require("express-validator");

const ApiError = require("../utils/ApiError");

const MONTH_REGEX = /^\d{4}-(0[1-9]|1[0-2])$/;

const handleValidation = (req, res, next) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    const message = errors
      .array()
      .map((error) => error.msg)
      .join(", ");

    return next(new ApiError(400, message, "VALIDATION_ERROR"));
  }

  return next();
};

const createBudgetValidation = [
  body("month")
    .trim()
    .notEmpty()
    .withMessage("Month is required")
    .matches(MONTH_REGEX)
    .withMessage("Month must be in YYYY-MM format"),
  body("monthlyGoal")
    .notEmpty()
    .withMessage("Monthly goal is required")
    .isFloat({ gt: 0 })
    .withMessage("Monthly goal must be a positive number"),
  body("savingsTarget")
    .notEmpty()
    .withMessage("Savings target is required")
    .isFloat({ min: 0 })
    .withMessage("Savings target must be a non-negative number"),
  body("categoryLimits")
    .optional()
    .isObject()
    .withMessage("Category limits must be an object"),
  handleValidation,
];

const updateBudgetValidation = [
  body("month").optional().trim().matches(MONTH_REGEX).withMessage("Month must be in YYYY-MM format"),
  body("monthlyGoal")
    .optional()
    .isFloat({ gt: 0 })
    .withMessage("Monthly goal must be a positive number"),
  body("savingsTarget")
    .optional()
    .isFloat({ min: 0 })
    .withMessage("Savings target must be a non-negative number"),
  body("categoryLimits")
    .optional()
    .isObject()
    .withMessage("Category limits must be an object"),
  handleValidation,
];

const budgetIdValidation = [
  param("id").trim().notEmpty().withMessage("Budget id is required"),
  handleValidation,
];

module.exports = {
  createBudgetValidation,
  updateBudgetValidation,
  budgetIdValidation,
};
