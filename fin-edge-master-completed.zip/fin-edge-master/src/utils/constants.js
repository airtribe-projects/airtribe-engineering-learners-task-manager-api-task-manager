const TRANSACTION_TYPES = ["income", "expense"];

const DEFAULT_SUMMARY_CACHE_TTL_MS = 30 * 1000; // 30 seconds

module.exports = {
  TRANSACTION_TYPES,
  DEFAULT_SUMMARY_CACHE_TTL_MS,
};
