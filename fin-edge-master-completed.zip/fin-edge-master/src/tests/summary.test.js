const request = require("supertest");

process.env.JWT_SECRET = "test-finedge-secret";
process.env.JWT_EXPIRES_IN = "1d";

const app = require("../app");
const UserModel = require("../models/user.model");
const TransactionModel = require("../models/transaction.model");
const cache = require("../cache/memoryCache");

describe("Summary", () => {
  const user = {
    name: "Dev Parmar",
    email: "dev-summary@example.com",
    password: "devdevdev",
  };

  let token;

  beforeEach(async () => {
    await UserModel.replaceUsers([]);
    await TransactionModel.replaceTransactions([]);
    cache.clearAll();

    const registerResponse = await request(app).post("/api/v1/users").send(user);
    token = registerResponse.body.data.token;
  });

  const authed = (req) => req.set("Authorization", `Bearer ${token}`);

  test("GET /api/v1/summary computes totals, balance, and trends", async () => {
    await authed(request(app).post("/api/v1/transactions")).send({
      type: "income",
      category: "Salary",
      amount: 50000,
      date: "2026-07-01",
    });
    await authed(request(app).post("/api/v1/transactions")).send({
      type: "expense",
      category: "Food",
      amount: 5000,
      date: "2026-07-05",
    });

    const response = await authed(request(app).get("/api/v1/summary"));

    expect(response.status).toBe(200);
    expect(response.body.data.totalIncome).toBe(50000);
    expect(response.body.data.totalExpense).toBe(5000);
    expect(response.body.data.balance).toBe(45000);
    expect(response.body.data.monthlyTrends).toHaveLength(1);
    expect(response.body.data.monthlyTrends[0].month).toBe("2026-07");
  });

  test("GET /api/v1/summary serves cached results on repeat calls", async () => {
    await authed(request(app).post("/api/v1/transactions")).send({
      type: "income",
      category: "Salary",
      amount: 1000,
      date: "2026-07-01",
    });

    const first = await authed(request(app).get("/api/v1/summary"));
    expect(first.body.data.cached).toBe(false);

    const second = await authed(request(app).get("/api/v1/summary"));
    expect(second.body.data.cached).toBe(true);
    expect(second.body.data.totalIncome).toBe(1000);
  });

  test("GET /api/v1/summary invalidates cache after a new transaction", async () => {
    await authed(request(app).post("/api/v1/transactions")).send({
      type: "income",
      category: "Salary",
      amount: 1000,
      date: "2026-07-01",
    });
    await authed(request(app).get("/api/v1/summary"));

    await authed(request(app).post("/api/v1/transactions")).send({
      type: "income",
      category: "Bonus",
      amount: 500,
      date: "2026-07-02",
    });

    const response = await authed(request(app).get("/api/v1/summary"));
    expect(response.body.data.cached).toBe(false);
    expect(response.body.data.totalIncome).toBe(1500);
  });

  test("GET /api/v1/summary requires authentication", async () => {
    const response = await request(app).get("/api/v1/summary");
    expect(response.status).toBe(401);
  });
});
