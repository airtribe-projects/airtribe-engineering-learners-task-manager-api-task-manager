const request = require("supertest");

process.env.JWT_SECRET = "test-finedge-secret";
process.env.JWT_EXPIRES_IN = "1d";

const app = require("../app");
const UserModel = require("../models/user.model");
const BudgetModel = require("../models/budget.model");

describe("Budgets", () => {
  const user = {
    name: "Dev Parmar",
    email: "dev-budgets@example.com",
    password: "devdevdev",
  };

  let token;

  beforeEach(async () => {
    await UserModel.replaceUsers([]);
    await BudgetModel.replaceBudgets([]);

    const registerResponse = await request(app).post("/api/v1/users").send(user);
    token = registerResponse.body.data.token;
  });

  const authed = (req) => req.set("Authorization", `Bearer ${token}`);

  test("POST /api/v1/budgets creates a budget", async () => {
    const response = await authed(request(app).post("/api/v1/budgets")).send({
      month: "2026-07",
      monthlyGoal: 40000,
      savingsTarget: 8000,
      categoryLimits: { food: 5000 },
    });

    expect(response.status).toBe(201);
    expect(response.body.data.budget.month).toBe("2026-07");
    expect(response.body.data.budget.monthlyGoal).toBe(40000);
  });

  test("POST /api/v1/budgets rejects a duplicate month", async () => {
    await authed(request(app).post("/api/v1/budgets")).send({
      month: "2026-07",
      monthlyGoal: 40000,
      savingsTarget: 8000,
    });

    const response = await authed(request(app).post("/api/v1/budgets")).send({
      month: "2026-07",
      monthlyGoal: 30000,
      savingsTarget: 5000,
    });

    expect(response.status).toBe(409);
    expect(response.body.code).toBe("BUDGET_EXISTS");
  });

  test("POST /api/v1/budgets rejects invalid input", async () => {
    const response = await authed(request(app).post("/api/v1/budgets")).send({
      month: "2026-13",
      monthlyGoal: -1,
      savingsTarget: -1,
    });

    expect(response.status).toBe(400);
    expect(response.body.code).toBe("VALIDATION_ERROR");
  });

  test("GET /api/v1/budgets lists the current user's budgets", async () => {
    await authed(request(app).post("/api/v1/budgets")).send({
      month: "2026-06",
      monthlyGoal: 35000,
      savingsTarget: 6000,
    });
    await authed(request(app).post("/api/v1/budgets")).send({
      month: "2026-07",
      monthlyGoal: 40000,
      savingsTarget: 8000,
    });

    const response = await authed(request(app).get("/api/v1/budgets"));

    expect(response.status).toBe(200);
    expect(response.body.data.budgets).toHaveLength(2);
  });

  test("PATCH /api/v1/budgets/:id updates a budget", async () => {
    const createResponse = await authed(request(app).post("/api/v1/budgets")).send({
      month: "2026-07",
      monthlyGoal: 40000,
      savingsTarget: 8000,
    });
    const id = createResponse.body.data.budget.id;

    const response = await authed(request(app).patch(`/api/v1/budgets/${id}`)).send({
      savingsTarget: 10000,
    });

    expect(response.status).toBe(200);
    expect(response.body.data.budget.savingsTarget).toBe(10000);
  });

  test("DELETE /api/v1/budgets/:id removes a budget", async () => {
    const createResponse = await authed(request(app).post("/api/v1/budgets")).send({
      month: "2026-07",
      monthlyGoal: 40000,
      savingsTarget: 8000,
    });
    const id = createResponse.body.data.budget.id;

    const deleteResponse = await authed(request(app).delete(`/api/v1/budgets/${id}`));
    expect(deleteResponse.status).toBe(200);

    const getResponse = await authed(request(app).get(`/api/v1/budgets/${id}`));
    expect(getResponse.status).toBe(404);
  });
});
