const request = require("supertest");

process.env.JWT_SECRET = "test-finedge-secret";
process.env.JWT_EXPIRES_IN = "1d";

const app = require("../app");
const UserModel = require("../models/user.model");

describe("User Authentication", () => {
  const user = {
    name: "Dev Parmar",
    email: "dev@example.com",
    password: "devdevdev",
    preferences: {
      currency: "INR",
      monthlySavingsGoal: 5000,
    },
  };

  beforeEach(async () => {
    await UserModel.replaceUsers([]);
  });

  test("POST /api/v1/users registers a new user", async () => {
    const response = await request(app).post("/api/v1/users").send(user);

    expect(response.status).toBe(201);
    expect(response.body.success).toBe(true);
    expect(response.body.data.token).toBeDefined();
    expect(response.body.data.user.email).toBe(user.email);
    expect(response.body.data.user.passwordHash).toBeUndefined();
  });

  test("POST /api/v1/users rejects duplicate emails", async () => {
    await request(app).post("/api/v1/users").send(user);
    const response = await request(app).post("/api/v1/users").send(user);

    expect(response.status).toBe(409);
    expect(response.body.code).toBe("USER_EXISTS");
  });

  test("POST /api/v1/users/login returns a JWT token", async () => {
    await request(app).post("/api/v1/users").send(user);
    const response = await request(app).post("/api/v1/users/login").send({
      email: user.email,
      password: user.password,
    });

    expect(response.status).toBe(200);
    expect(response.body.data.token).toBeDefined();
  });

  test("GET /api/v1/users/me requires a valid bearer token", async () => {
    const registerResponse = await request(app).post("/api/v1/users").send(user);
    const token = registerResponse.body.data.token;

    const response = await request(app)
      .get("/api/v1/users/me")
      .set("Authorization", `Bearer ${token}`);

    expect(response.status).toBe(200);
    expect(response.body.data.user.email).toBe(user.email);
  });

  test("PATCH /api/v1/users/me updates profile details", async () => {
    const registerResponse = await request(app).post("/api/v1/users").send(user);
    const token = registerResponse.body.data.token;

    const response = await request(app)
      .patch("/api/v1/users/me")
      .set("Authorization", `Bearer ${token}`)
      .send({ name: "Dev P" });

    expect(response.status).toBe(200);
    expect(response.body.data.user.name).toBe("Dev P");
  });

  test("GET and PATCH /api/v1/users/preferences manage user preferences", async () => {
    const registerResponse = await request(app).post("/api/v1/users").send(user);
    const token = registerResponse.body.data.token;
    const nextPreferences = {
      currency: "USD",
      monthlySavingsGoal: 7500,
      categories: ["food", "rent"],
    };

    const updateResponse = await request(app)
      .patch("/api/v1/users/preferences")
      .set("Authorization", `Bearer ${token}`)
      .send({ preferences: nextPreferences });

    expect(updateResponse.status).toBe(200);
    expect(updateResponse.body.data.preferences).toEqual(nextPreferences);

    const getResponse = await request(app)
      .get("/api/v1/users/preferences")
      .set("Authorization", `Bearer ${token}`);

    expect(getResponse.status).toBe(200);
    expect(getResponse.body.data.preferences).toEqual(nextPreferences);
  });

  test("PATCH /api/v1/users/password changes the password", async () => {
    const registerResponse = await request(app).post("/api/v1/users").send(user);
    const token = registerResponse.body.data.token;

    const response = await request(app)
      .patch("/api/v1/users/password")
      .set("Authorization", `Bearer ${token}`)
      .send({
        currentPassword: user.password,
        newPassword: "newdevdev",
      });

    expect(response.status).toBe(200);

    const loginResponse = await request(app).post("/api/v1/users/login").send({
      email: user.email,
      password: "newdevdev",
    });

    expect(loginResponse.status).toBe(200);
    expect(loginResponse.body.data.token).toBeDefined();
  });

  test("DELETE /api/v1/users/me removes the user account", async () => {
    const registerResponse = await request(app).post("/api/v1/users").send(user);
    const token = registerResponse.body.data.token;

    const response = await request(app)
      .delete("/api/v1/users/me")
      .set("Authorization", `Bearer ${token}`);

    expect(response.status).toBe(200);

    const loginResponse = await request(app).post("/api/v1/users/login").send({
      email: user.email,
      password: user.password,
    });

    expect(loginResponse.status).toBe(401);
  });

  test("POST /api/v1/users validates required input", async () => {
    const response = await request(app).post("/api/v1/users").send({
      email: "not-an-email",
      password: "123",
    });

    expect(response.status).toBe(400);
    expect(response.body.code).toBe("VALIDATION_ERROR");
  });
});
