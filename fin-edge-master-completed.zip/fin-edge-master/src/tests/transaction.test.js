const request = require("supertest");

process.env.JWT_SECRET = "test-finedge-secret";
process.env.JWT_EXPIRES_IN = "1d";

const app = require("../app");
const UserModel = require("../models/user.model");
const TransactionModel = require("../models/transaction.model");

describe("Transactions", () => {
  const user = {
    name: "Dev Parmar",
    email: "dev-transactions@example.com",
    password: "devdevdev",
  };

  let token;

  beforeEach(async () => {
    await UserModel.replaceUsers([]);
    await TransactionModel.replaceTransactions([]);

    const registerResponse = await request(app).post("/api/v1/users").send(user);
    token = registerResponse.body.data.token;
  });

  const authed = (req) => req.set("Authorization", `Bearer ${token}`);

  test("POST /api/v1/transactions creates a transaction", async () => {
    const response = await authed(request(app).post("/api/v1/transactions")).send({
      type: "income",
      category: "Salary",
      amount: 50000,
      date: "2026-07-01",
      description: "July salary",
    });

    expect(response.status).toBe(201);
    expect(response.body.success).toBe(true);
    expect(response.body.data.transaction.type).toBe("income");
    expect(response.body.data.transaction.amount).toBe(50000);
  });

  test("POST /api/v1/transactions rejects invalid input", async () => {
    const response = await authed(request(app).post("/api/v1/transactions")).send({
      type: "invalid-type",
      category: "",
      amount: -10,
      date: "not-a-date",
    });

    expect(response.status).toBe(400);
    expect(response.body.code).toBe("VALIDATION_ERROR");
  });

  test("POST /api/v1/transactions requires authentication", async () => {
    const response = await request(app).post("/api/v1/transactions").send({
      type: "income",
      category: "Salary",
      amount: 100,
      date: "2026-07-01",
    });

    expect(response.status).toBe(401);
  });

  test("GET /api/v1/transactions lists only the current user's transactions", async () => {
    await authed(request(app).post("/api/v1/transactions")).send({
      type: "income",
      category: "Salary",
      amount: 1000,
      date: "2026-07-01",
    });
    await authed(request(app).post("/api/v1/transactions")).send({
      type: "expense",
      category: "Food",
      amount: 200,
      date: "2026-07-05",
    });

    const response = await authed(request(app).get("/api/v1/transactions"));

    expect(response.status).toBe(200);
    expect(response.body.data.transactions).toHaveLength(2);
  });

  test("GET /api/v1/transactions filters by type", async () => {
    await authed(request(app).post("/api/v1/transactions")).send({
      type: "income",
      category: "Salary",
      amount: 1000,
      date: "2026-07-01",
    });
    await authed(request(app).post("/api/v1/transactions")).send({
      type: "expense",
      category: "Food",
      amount: 200,
      date: "2026-07-05",
    });

    const response = await authed(request(app).get("/api/v1/transactions?type=expense"));

    expect(response.status).toBe(200);
    expect(response.body.data.transactions).toHaveLength(1);
    expect(response.body.data.transactions[0].type).toBe("expense");
  });

  test("GET /api/v1/transactions/:id fetches a single transaction", async () => {
    const createResponse = await authed(request(app).post("/api/v1/transactions")).send({
      type: "expense",
      category: "Travel",
      amount: 500,
      date: "2026-07-10",
    });
    const id = createResponse.body.data.transaction.id;

    const response = await authed(request(app).get(`/api/v1/transactions/${id}`));

    expect(response.status).toBe(200);
    expect(response.body.data.transaction.id).toBe(id);
  });

  test("GET /api/v1/transactions/:id returns 404 for a missing transaction", async () => {
    const response = await authed(request(app).get("/api/v1/transactions/does-not-exist"));

    expect(response.status).toBe(404);
    expect(response.body.code).toBe("TRANSACTION_NOT_FOUND");
  });

  test("PATCH /api/v1/transactions/:id updates a transaction", async () => {
    const createResponse = await authed(request(app).post("/api/v1/transactions")).send({
      type: "expense",
      category: "Travel",
      amount: 500,
      date: "2026-07-10",
    });
    const id = createResponse.body.data.transaction.id;

    const response = await authed(request(app).patch(`/api/v1/transactions/${id}`)).send({
      amount: 750,
    });

    expect(response.status).toBe(200);
    expect(response.body.data.transaction.amount).toBe(750);
  });

  test("DELETE /api/v1/transactions/:id removes a transaction", async () => {
    const createResponse = await authed(request(app).post("/api/v1/transactions")).send({
      type: "expense",
      category: "Travel",
      amount: 500,
      date: "2026-07-10",
    });
    const id = createResponse.body.data.transaction.id;

    const deleteResponse = await authed(request(app).delete(`/api/v1/transactions/${id}`));
    expect(deleteResponse.status).toBe(200);

    const getResponse = await authed(request(app).get(`/api/v1/transactions/${id}`));
    expect(getResponse.status).toBe(404);
  });
});
