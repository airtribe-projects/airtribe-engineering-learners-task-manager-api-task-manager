const asyncHandler = require("../utils/asyncHandler");
const ApiResponse = require("../utils/ApiResponse");
const budgetService = require("../services/budget.service");

const createBudget = asyncHandler(async (req, res) => {
  const budget = await budgetService.createBudget(req.user.id, req.body);
  return res.status(201).json(new ApiResponse("Budget created successfully", { budget }));
});

const getBudgets = asyncHandler(async (req, res) => {
  const budgets = await budgetService.getBudgets(req.user.id);
  return res.status(200).json(new ApiResponse("Budgets fetched successfully", { budgets }));
});

const getBudgetById = asyncHandler(async (req, res) => {
  const budget = await budgetService.getBudgetById(req.user.id, req.params.id);
  return res.status(200).json(new ApiResponse("Budget fetched successfully", { budget }));
});

const updateBudget = asyncHandler(async (req, res) => {
  const budget = await budgetService.updateBudget(req.user.id, req.params.id, req.body);
  return res.status(200).json(new ApiResponse("Budget updated successfully", { budget }));
});

const deleteBudget = asyncHandler(async (req, res) => {
  await budgetService.deleteBudget(req.user.id, req.params.id);
  return res.status(200).json(new ApiResponse("Budget deleted successfully"));
});

module.exports = {
  createBudget,
  getBudgets,
  getBudgetById,
  updateBudget,
  deleteBudget,
};
