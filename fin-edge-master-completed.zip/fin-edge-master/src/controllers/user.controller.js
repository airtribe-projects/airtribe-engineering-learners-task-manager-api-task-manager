const asyncHandler = require("../utils/asyncHandler");
const ApiResponse = require("../utils/ApiResponse");
const userService = require("../services/user.service");

const register = asyncHandler(async (req, res) => {
  const data = await userService.registerUser(req.body);
  return res.status(201).json(new ApiResponse("User registered successfully", data));
});

const login = asyncHandler(async (req, res) => {
  const data = await userService.loginUser(req.body);
  return res.status(200).json(new ApiResponse("Login successful", data));
});

const getProfile = asyncHandler(async (req, res) => {
  const user = await userService.getUserById(req.user.id);
  return res.status(200).json(new ApiResponse("User profile fetched successfully", { user }));
});

const updateProfile = asyncHandler(async (req, res) => {
  const user = await userService.updateProfile(req.user.id, req.body);
  return res.status(200).json(new ApiResponse("User profile updated successfully", { user }));
});

const getPreferences = asyncHandler(async (req, res) => {
  const preferences = await userService.getPreferences(req.user.id);
  return res.status(200).json(new ApiResponse("User preferences fetched successfully", { preferences }));
});

const updatePreferences = asyncHandler(async (req, res) => {
  const preferences = await userService.updatePreferences(req.user.id, req.body.preferences);
  return res.status(200).json(new ApiResponse("User preferences updated successfully", { preferences }));
});

const changePassword = asyncHandler(async (req, res) => {
  await userService.changePassword(req.user.id, req.body);
  return res.status(200).json(new ApiResponse("Password changed successfully"));
});

const deleteAccount = asyncHandler(async (req, res) => {
  await userService.deleteAccount(req.user.id);
  return res.status(200).json(new ApiResponse("User account deleted successfully"));
});

module.exports = {
  changePassword,
  deleteAccount,
  getPreferences,
  getProfile,
  login,
  register,
  updatePreferences,
  updateProfile,
};
