const asyncHandler = require("../utils/asyncHandler");
const ApiResponse = require("../utils/ApiResponse");
const transactionService = require("../services/transaction.service");

const createTransaction = asyncHandler(async (req, res) => {
  const transaction = await transactionService.createTransaction(req.user.id, req.body);
  return res.status(201).json(new ApiResponse("Transaction created successfully", { transaction }));
});

const getTransactions = asyncHandler(async (req, res) => {
  const { type, category, startDate, endDate } = req.query;
  const transactions = await transactionService.getTransactions(req.user.id, {
    type,
    category,
    startDate,
    endDate,
  });
  return res
    .status(200)
    .json(new ApiResponse("Transactions fetched successfully", { transactions }));
});

const getTransactionById = asyncHandler(async (req, res) => {
  const transaction = await transactionService.getTransactionById(req.user.id, req.params.id);
  return res.status(200).json(new ApiResponse("Transaction fetched successfully", { transaction }));
});

const updateTransaction = asyncHandler(async (req, res) => {
  const transaction = await transactionService.updateTransaction(
    req.user.id,
    req.params.id,
    req.body
  );
  return res.status(200).json(new ApiResponse("Transaction updated successfully", { transaction }));
});

const deleteTransaction = asyncHandler(async (req, res) => {
  await transactionService.deleteTransaction(req.user.id, req.params.id);
  return res.status(200).json(new ApiResponse("Transaction deleted successfully"));
});

module.exports = {
  createTransaction,
  getTransactions,
  getTransactionById,
  updateTransaction,
  deleteTransaction,
};
