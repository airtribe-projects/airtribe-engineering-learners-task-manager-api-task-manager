const asyncHandler = require("../utils/asyncHandler");
const ApiResponse = require("../utils/ApiResponse");
const summaryService = require("../services/summary.service");

const getSummary = asyncHandler(async (req, res) => {
  const { category, startDate, endDate } = req.query;
  const summary = await summaryService.getSummary(req.user.id, { category, startDate, endDate });
  return res.status(200).json(new ApiResponse("Summary fetched successfully", summary));
});

module.exports = {
  getSummary,
};
