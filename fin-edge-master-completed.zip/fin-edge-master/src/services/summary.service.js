const TransactionModel = require("../models/transaction.model");
const cache = require("../cache/memoryCache");
const { DEFAULT_SUMMARY_CACHE_TTL_MS } = require("../utils/constants");

const buildCacheKey = (userId, filters) =>
  `summary:${userId}:${JSON.stringify(filters)}`;

const getMonthKey = (dateString) => dateString.slice(0, 7); // YYYY-MM

const filterTransactions = (transactions, filters) => {
  let filtered = transactions;

  if (filters.category) {
    const category = filters.category.toLowerCase();
    filtered = filtered.filter((transaction) => transaction.category.toLowerCase() === category);
  }

  if (filters.startDate) {
    const start = new Date(filters.startDate).getTime();
    filtered = filtered.filter((transaction) => new Date(transaction.date).getTime() >= start);
  }

  if (filters.endDate) {
    const end = new Date(filters.endDate).getTime();
    filtered = filtered.filter((transaction) => new Date(transaction.date).getTime() <= end);
  }

  return filtered;
};

const computeSummary = (transactions) => {
  let totalIncome = 0;
  let totalExpense = 0;
  const monthlyTrends = {};
  const categoryBreakdown = {};

  for (const transaction of transactions) {
    const amount = Number(transaction.amount);
    const monthKey = getMonthKey(transaction.date);

    if (!monthlyTrends[monthKey]) {
      monthlyTrends[monthKey] = { month: monthKey, income: 0, expense: 0, balance: 0 };
    }

    if (!categoryBreakdown[transaction.category]) {
      categoryBreakdown[transaction.category] = { category: transaction.category, income: 0, expense: 0 };
    }

    if (transaction.type === "income") {
      totalIncome += amount;
      monthlyTrends[monthKey].income += amount;
      categoryBreakdown[transaction.category].income += amount;
    } else {
      totalExpense += amount;
      monthlyTrends[monthKey].expense += amount;
      categoryBreakdown[transaction.category].expense += amount;
    }
  }

  const monthlyTrendsList = Object.values(monthlyTrends)
    .map((entry) => ({ ...entry, balance: entry.income - entry.expense }))
    .sort((a, b) => (a.month < b.month ? -1 : 1));

  const categoryBreakdownList = Object.values(categoryBreakdown).sort(
    (a, b) => b.expense + b.income - (a.expense + a.income)
  );

  return {
    totalIncome,
    totalExpense,
    balance: totalIncome - totalExpense,
    transactionCount: transactions.length,
    monthlyTrends: monthlyTrendsList,
    categoryBreakdown: categoryBreakdownList,
  };
};

const getSummary = async (userId, filters = {}) => {
  const cacheKey = buildCacheKey(userId, filters);
  const cached = cache.get(cacheKey);

  if (cached) {
    return { ...cached, cached: true };
  }

  const transactions = await TransactionModel.findTransactionsByUserId(userId);
  const filtered = filterTransactions(transactions, filters);
  const summary = computeSummary(filtered);

  cache.set(cacheKey, summary, DEFAULT_SUMMARY_CACHE_TTL_MS);

  return { ...summary, cached: false };
};

module.exports = {
  getSummary,
};
