const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");

const UserModel = require("../models/user.model");
const ApiError = require("../utils/ApiError");
const { env } = require("../config/env");

const sanitizeUser = (user) => ({
  id: user.id,
  name: user.name,
  email: user.email,
  preferences: user.preferences,
  createdAt: user.createdAt,
});

const createToken = (user) => {
  if (!env.JWT_SECRET) {
    throw new ApiError(500, "JWT secret is not configured", "JWT_SECRET_MISSING");
  }

  return jwt.sign(
    {
      id: user.id,
      email: user.email,
    },
    env.JWT_SECRET,
    { expiresIn: env.JWT_EXPIRES_IN }
  );
};

const registerUser = async ({ name, email, password, preferences = {} }) => {
  const normalizedEmail = email.trim().toLowerCase();
  const existingUser = await UserModel.findUserByEmail(normalizedEmail);

  if (existingUser) {
    throw new ApiError(409, "User with this email already exists", "USER_EXISTS");
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const now = new Date().toISOString();

  const user = await UserModel.createUser({
    id: crypto.randomUUID(),
    name: name.trim(),
    email: normalizedEmail,
    passwordHash,
    preferences,
    createdAt: now,
    updatedAt: now,
  });

  return {
    user: sanitizeUser(user),
    token: createToken(user),
  };
};

const loginUser = async ({ email, password }) => {
  const user = await UserModel.findUserByEmail(email.trim().toLowerCase());

  if (!user) {
    throw new ApiError(401, "Invalid email or password", "INVALID_CREDENTIALS");
  }

  const passwordMatches = await bcrypt.compare(password, user.passwordHash);

  if (!passwordMatches) {
    throw new ApiError(401, "Invalid email or password", "INVALID_CREDENTIALS");
  }

  return {
    user: sanitizeUser(user),
    token: createToken(user),
  };
};

const getUserById = async (id) => {
  const user = await UserModel.findUserById(id);

  if (!user) {
    throw new ApiError(404, "User not found", "USER_NOT_FOUND");
  }

  return sanitizeUser(user);
};

const updateProfile = async (id, updates) => {
  const currentUser = await UserModel.findUserById(id);

  if (!currentUser) {
    throw new ApiError(404, "User not found", "USER_NOT_FOUND");
  }

  const nextUpdates = {};

  if (updates.name !== undefined) {
    nextUpdates.name = updates.name.trim();
  }

  if (updates.email !== undefined) {
    const normalizedEmail = updates.email.trim().toLowerCase();
    const existingUser = await UserModel.findUserByEmail(normalizedEmail);

    if (existingUser && existingUser.id !== id) {
      throw new ApiError(409, "User with this email already exists", "USER_EXISTS");
    }

    nextUpdates.email = normalizedEmail;
  }

  const updatedUser = await UserModel.updateUserById(id, nextUpdates);
  return sanitizeUser(updatedUser);
};

const getPreferences = async (id) => {
  const user = await UserModel.findUserById(id);

  if (!user) {
    throw new ApiError(404, "User not found", "USER_NOT_FOUND");
  }

  return user.preferences || {};
};

const updatePreferences = async (id, preferences) => {
  const user = await UserModel.updateUserById(id, { preferences });

  if (!user) {
    throw new ApiError(404, "User not found", "USER_NOT_FOUND");
  }

  return user.preferences;
};

const changePassword = async (id, { currentPassword, newPassword }) => {
  const user = await UserModel.findUserById(id);

  if (!user) {
    throw new ApiError(404, "User not found", "USER_NOT_FOUND");
  }

  const passwordMatches = await bcrypt.compare(currentPassword, user.passwordHash);

  if (!passwordMatches) {
    throw new ApiError(401, "Current password is incorrect", "INVALID_CURRENT_PASSWORD");
  }

  const passwordHash = await bcrypt.hash(newPassword, 10);
  await UserModel.updateUserById(id, { passwordHash });
};

const deleteAccount = async (id) => {
  const deleted = await UserModel.deleteUserById(id);

  if (!deleted) {
    throw new ApiError(404, "User not found", "USER_NOT_FOUND");
  }
};

module.exports = {
  changePassword,
  deleteAccount,
  getPreferences,
  getUserById,
  loginUser,
  registerUser,
  updatePreferences,
  updateProfile,
};
