const crypto = require("crypto");

const TransactionModel = require("../models/transaction.model");
const ApiError = require("../utils/ApiError");
const cache = require("../cache/memoryCache");

const sanitizeTransaction = (transaction) => ({
  id: transaction.id,
  type: transaction.type,
  category: transaction.category,
  amount: transaction.amount,
  date: transaction.date,
  description: transaction.description,
  createdAt: transaction.createdAt,
  updatedAt: transaction.updatedAt,
});

// Any transaction change makes previously cached /summary responses stale,
// so we drop every cached summary belonging to this user.
const invalidateSummaryCache = (userId) => {
  cache.clearByPrefix(`summary:${userId}:`);
};

const createTransaction = async (userId, payload) => {
  const now = new Date().toISOString();

  const transaction = await TransactionModel.createTransaction({
    id: crypto.randomUUID(),
    userId,
    type: payload.type,
    category: payload.category.trim(),
    amount: Number(payload.amount),
    date: new Date(payload.date).toISOString(),
    description: payload.description ? payload.description.trim() : undefined,
    createdAt: now,
    updatedAt: now,
  });

  invalidateSummaryCache(userId);

  return sanitizeTransaction(transaction);
};

const getTransactions = async (userId, filters = {}) => {
  let transactions = await TransactionModel.findTransactionsByUserId(userId);

  if (filters.type) {
    transactions = transactions.filter((transaction) => transaction.type === filters.type);
  }

  if (filters.category) {
    const category = filters.category.toLowerCase();
    transactions = transactions.filter(
      (transaction) => transaction.category.toLowerCase() === category
    );
  }

  if (filters.startDate) {
    const start = new Date(filters.startDate).getTime();
    transactions = transactions.filter((transaction) => new Date(transaction.date).getTime() >= start);
  }

  if (filters.endDate) {
    const end = new Date(filters.endDate).getTime();
    transactions = transactions.filter((transaction) => new Date(transaction.date).getTime() <= end);
  }

  transactions.sort((a, b) => new Date(b.date) - new Date(a.date));

  return transactions.map(sanitizeTransaction);
};

const getTransactionById = async (userId, id) => {
  const transaction = await TransactionModel.findTransactionById(id, userId);

  if (!transaction) {
    throw new ApiError(404, "Transaction not found", "TRANSACTION_NOT_FOUND");
  }

  return sanitizeTransaction(transaction);
};

const updateTransaction = async (userId, id, updates) => {
  const nextUpdates = {};

  if (updates.type !== undefined) nextUpdates.type = updates.type;
  if (updates.category !== undefined) nextUpdates.category = updates.category.trim();
  if (updates.amount !== undefined) nextUpdates.amount = Number(updates.amount);
  if (updates.date !== undefined) nextUpdates.date = new Date(updates.date).toISOString();
  if (updates.description !== undefined) nextUpdates.description = updates.description.trim();

  const transaction = await TransactionModel.updateTransactionById(id, userId, nextUpdates);

  if (!transaction) {
    throw new ApiError(404, "Transaction not found", "TRANSACTION_NOT_FOUND");
  }

  invalidateSummaryCache(userId);

  return sanitizeTransaction(transaction);
};

const deleteTransaction = async (userId, id) => {
  const deleted = await TransactionModel.deleteTransactionById(id, userId);

  if (!deleted) {
    throw new ApiError(404, "Transaction not found", "TRANSACTION_NOT_FOUND");
  }

  invalidateSummaryCache(userId);
};

module.exports = {
  createTransaction,
  getTransactions,
  getTransactionById,
  updateTransaction,
  deleteTransaction,
};
