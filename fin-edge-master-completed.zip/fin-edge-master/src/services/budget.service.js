const crypto = require("crypto");

const BudgetModel = require("../models/budget.model");
const ApiError = require("../utils/ApiError");

const sanitizeBudget = (budget) => ({
  id: budget.id,
  month: budget.month,
  monthlyGoal: budget.monthlyGoal,
  savingsTarget: budget.savingsTarget,
  categoryLimits: budget.categoryLimits || {},
  createdAt: budget.createdAt,
  updatedAt: budget.updatedAt,
});

const createBudget = async (userId, payload) => {
  const existingBudget = await BudgetModel.findBudgetByMonth(userId, payload.month);

  if (existingBudget) {
    throw new ApiError(409, "A budget for this month already exists", "BUDGET_EXISTS");
  }

  const now = new Date().toISOString();

  const budget = await BudgetModel.createBudget({
    id: crypto.randomUUID(),
    userId,
    month: payload.month,
    monthlyGoal: Number(payload.monthlyGoal),
    savingsTarget: Number(payload.savingsTarget),
    categoryLimits: payload.categoryLimits || {},
    createdAt: now,
    updatedAt: now,
  });

  return sanitizeBudget(budget);
};

const getBudgets = async (userId) => {
  const budgets = await BudgetModel.findBudgetsByUserId(userId);
  budgets.sort((a, b) => (a.month < b.month ? 1 : -1));
  return budgets.map(sanitizeBudget);
};

const getBudgetById = async (userId, id) => {
  const budget = await BudgetModel.findBudgetById(id, userId);

  if (!budget) {
    throw new ApiError(404, "Budget not found", "BUDGET_NOT_FOUND");
  }

  return sanitizeBudget(budget);
};

const updateBudget = async (userId, id, updates) => {
  if (updates.month !== undefined) {
    const existingBudget = await BudgetModel.findBudgetByMonth(userId, updates.month);

    if (existingBudget && existingBudget.id !== id) {
      throw new ApiError(409, "A budget for this month already exists", "BUDGET_EXISTS");
    }
  }

  const nextUpdates = {};

  if (updates.month !== undefined) nextUpdates.month = updates.month;
  if (updates.monthlyGoal !== undefined) nextUpdates.monthlyGoal = Number(updates.monthlyGoal);
  if (updates.savingsTarget !== undefined) nextUpdates.savingsTarget = Number(updates.savingsTarget);
  if (updates.categoryLimits !== undefined) nextUpdates.categoryLimits = updates.categoryLimits;

  const budget = await BudgetModel.updateBudgetById(id, userId, nextUpdates);

  if (!budget) {
    throw new ApiError(404, "Budget not found", "BUDGET_NOT_FOUND");
  }

  return sanitizeBudget(budget);
};

const deleteBudget = async (userId, id) => {
  const deleted = await BudgetModel.deleteBudgetById(id, userId);

  if (!deleted) {
    throw new ApiError(404, "Budget not found", "BUDGET_NOT_FOUND");
  }
};

module.exports = {
  createBudget,
  getBudgets,
  getBudgetById,
  updateBudget,
  deleteBudget,
};
