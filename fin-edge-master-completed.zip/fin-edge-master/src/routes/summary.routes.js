const express = require("express");

const summaryController = require("../controllers/summary.controller");
const authMiddleware = require("../middleware/auth.middleware");

const router = express.Router();

router.use(authMiddleware);

router.get("/", summaryController.getSummary);

module.exports = router;
