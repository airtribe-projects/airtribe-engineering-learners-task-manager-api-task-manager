const express = require("express");

const transactionController = require("../controllers/transaction.controller");
const authMiddleware = require("../middleware/auth.middleware");
const {
  createTransactionValidation,
  updateTransactionValidation,
  transactionIdValidation,
  listTransactionsValidation,
} = require("../validations/transaction.validation");

const router = express.Router();

router.use(authMiddleware);

router.post("/", createTransactionValidation, transactionController.createTransaction);
router.get("/", listTransactionsValidation, transactionController.getTransactions);
router.get("/:id", transactionIdValidation, transactionController.getTransactionById);
router.patch(
  "/:id",
  transactionIdValidation,
  updateTransactionValidation,
  transactionController.updateTransaction
);
router.delete("/:id", transactionIdValidation, transactionController.deleteTransaction);

module.exports = router;
