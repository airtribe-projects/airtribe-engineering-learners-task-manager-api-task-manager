const express = require("express");

const userRoutes = require("./user.routes");
const transactionRoutes = require("./transaction.routes");
const budgetRoutes = require("./budget.routes");
const summaryRoutes = require("./summary.routes");

const router = express.Router();

router.use("/users", userRoutes);
router.use("/transactions", transactionRoutes);
router.use("/budgets", budgetRoutes);
router.use("/summary", summaryRoutes);

module.exports = router;
