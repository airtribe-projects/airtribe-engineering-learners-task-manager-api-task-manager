const express = require("express");

const budgetController = require("../controllers/budget.controller");
const authMiddleware = require("../middleware/auth.middleware");
const {
  createBudgetValidation,
  updateBudgetValidation,
  budgetIdValidation,
} = require("../validations/budget.validation");

const router = express.Router();

router.use(authMiddleware);

router.post("/", createBudgetValidation, budgetController.createBudget);
router.get("/", budgetController.getBudgets);
router.get("/:id", budgetIdValidation, budgetController.getBudgetById);
router.patch("/:id", budgetIdValidation, updateBudgetValidation, budgetController.updateBudget);
router.delete("/:id", budgetIdValidation, budgetController.deleteBudget);

module.exports = router;
