const express = require("express");

const userController = require("../controllers/user.controller");
const authMiddleware = require("../middleware/auth.middleware");
const {
  changePasswordValidation,
  loginValidation,
  preferencesValidation,
  registerValidation,
  updateProfileValidation,
} = require("../validations/user.validation");

const router = express.Router();

router.post("/", registerValidation, userController.register);
router.post("/login", loginValidation, userController.login);
router.get("/me", authMiddleware, userController.getProfile);
router.patch("/me", authMiddleware, updateProfileValidation, userController.updateProfile);
router.get("/preferences", authMiddleware, userController.getPreferences);
router.patch(
  "/preferences",
  authMiddleware,
  preferencesValidation,
  userController.updatePreferences
);
router.patch(
  "/password",
  authMiddleware,
  changePasswordValidation,
  userController.changePassword
);
router.delete("/me", authMiddleware, userController.deleteAccount);

module.exports = router;
